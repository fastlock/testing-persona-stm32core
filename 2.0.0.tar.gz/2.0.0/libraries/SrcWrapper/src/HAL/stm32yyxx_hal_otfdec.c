#ifdef STM32H7xx
  #include "stm32h7xx_hal_otfdec.c"
#endif
#ifdef STM32L5xx
  #include "stm32l5xx_hal_otfdec.c"
#endif
