#ifdef VIRTIOCON

#include "libmetal/lib/system/generic/cortexm/sys.c"

#endif /* VIRTIOCON */
