#ifndef _STM32YYXX_LL_FMAC_H_
#define _STM32YYXX_LL_FMAC_H_
/* LL raised several warnings, ignore them */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wstrict-aliasing"

#ifdef STM32G4xx
  #include "stm32g4xx_ll_fmac.h"
#endif
#ifdef STM32H7xx
  #include "stm32h7xx_ll_fmac.h"
#endif
#pragma GCC diagnostic pop
#endif /* _STM32YYXX_LL_FMAC_H_ */
